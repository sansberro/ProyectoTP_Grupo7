#!/bin/bash

#si el primer argumento es -help desplega la ayuda para el usuario
if [[ "$1" == "-help" ]]; then
	echo "Para usar el script escribe: backup_full.sh <origen> <destino>"
	echo "Ejemplo: backup_full.sh /var/log /backup_dir"
	exit 0
fi 


#corroborar con IF -z si los argumentos 1 y 2 estan vacios.
if [[ -z $1 || -z $2 ]]; then
	echo "Error: Debes especificar origen y destino como 1er y 2do argumento respectivamente."
	exit 1
fi
#verificar que exista el origen
if [[ ! -d "$1" ]]; then
  echo "No exite el origen ingresado."
  exit 1
fi
#mountpoint verifica si el segundo argumento es un montaje.
if ! mountpoint -q "$2"; then
  echo "El destion no existe o no esta montado."
  exit 1
fi

#Nombre del archivo
#comando date trae la fecha con formato año mes dia.
FECHA=$(date +%Y%m%d)
#basename guarda el ultimo nombre de una ruta
NOMBRE=$(basename "$1")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

#Ejecucion
tar -czf "$2/$ARCHIVO" "$1"

















