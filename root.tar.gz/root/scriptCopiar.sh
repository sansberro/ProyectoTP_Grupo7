#!/bin/bash
mkdir -p /home/alumno/backups
cp -r /var/log /home/alumno/backups/
