#!/bin/bash
tar -czf /home/alumno/backup archivo.tar.gz /home/alumno/backups
