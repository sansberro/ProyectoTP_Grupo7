#!/bin/bash
date >> /home/alumno/date_hour.log
